function Genome(perceptron, fitness) {
	
	this.perceptron = perceptron;
	this.fitness = fitness;
}
